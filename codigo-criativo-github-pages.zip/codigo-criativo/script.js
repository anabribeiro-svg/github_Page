// Fecha o menu de navegação no celular depois de clicar em uma seção.
document.querySelectorAll(".navbar-nav .nav-link").forEach(function (link) {
  link.addEventListener("click", function () {
    const menu = document.querySelector("#menu");
    if (menu && menu.classList.contains("show")) {
      bootstrap.Collapse.getOrCreateInstance(menu).hide();
    }
  });
});

// Pequena animação de entrada quando as seções aparecem na tela.
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("is-visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".learning-item, .project-card, .section-heading, .about-copy").forEach((element) => {
  element.classList.add("reveal");
  observer.observe(element);
});
